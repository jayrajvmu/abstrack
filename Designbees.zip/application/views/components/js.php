


          <!-- Jquery Js -->
    <script src="<?php echo base_url(); ?>assets/js/vendor/jquery-3.6.0.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/isotope.pkgd.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/imagesloaded.pkgd.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/odometer.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/jquery-appear.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/slick.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/sal.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/jquery.magnific-popup.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/js.cookie.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/jquery.style.switcher.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/jquery.countdown.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/tilt.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/green-audio-player.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor/jquery.nav.js"></script>

    <!-- Site Scripts -->
    <script src="<?php echo base_url(); ?>assets/js/app.js"></script>