<head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Askbootstrap">
      <meta name="author" content="Askbootstrap">
      <title>:: Creative Agency ::</title>
      <link rel="stylesheet"href="<?php echo base_url(); ?>assets/css/vendor/odometer-theme-default.css">

<!-- Site Stylesheet -->
<link rel="stylesheet"href="<?php echo base_url(); ?>assets/css/app.css">
   </head>